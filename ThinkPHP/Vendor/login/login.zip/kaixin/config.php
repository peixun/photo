<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', '13957762217224051594e93e19edfff0');
define('CONSUMER_SECRET', '6589cbd4421a5ab2c137da3328cd4313');
